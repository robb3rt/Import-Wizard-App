(function() {
  return {
    defaultState: "phase0",
    requests: {
        sendData: function(data){
            return {
                url: '/api/v2/imports/tickets/create_many.json',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(data)
            };
        }
    },
    events: {
      'pane.activated': 'prepareApp',
      'click .option.tickets': 'switchToPhase',
      'click #upload_link': 'uploadFile',
      'change #upload': 'getFileContents',
      'dragover .drop .wzrd': 'allowDrop',
      'drop .drop .wzrd': 'dropFile',
    },
    dropFile: function(evt){
        evt.preventDefault();
        this.getFileContents(evt);
    },
    allowDrop: function(evt) {
        evt.stopPropagation();
        evt.preventDefault();
    },
    prepareApp: function() {
        this.$('#mainsection')[0].parentNode.style.padding = 0;
        this.$('#mainsection')[0].parentNode.style.marginTop = '85px';
        this.$('#mainsection')[0].parentNode.style.backgroundColor = '#e7e7e7';
    },
    switchToPhase: function() {
        this.switchTo('phase1', {
            option: "tickets"
        });
        //switch to template
        this.$('header.IWphase0')[0].classList.remove('IWphase0');
        this.$('header')[0].classList.add('IWphase1');
    },
    uploadFile: function(e){
        e.preventDefault();
        e.stopPropagation();
        this.$('#upload:hidden').trigger('click');
    },
    getFileContents: function(evt){
        this.switchTo('phase2');
        this.$('header.IWphase1')[0].classList.remove('IWphase1');
        this.$('header')[0].classList.add('IWphase2');
        var that = this;
        var f =  evt.target.files ? evt.target.files[0] : evt.dataTransfer.files[0];
        if (f) {
            /* globals FileReader */
            var r = new FileReader();
            r.onload = function(e) {
                var c = e.target.result;
                var obj = that.CSVtoJSON(c, that.guessDelimiter(c));
                that.prepareUpload(obj);
            };
            r.readAsText(f);
            that.store('previewfile', null);
        }
    },
    prepareUpload: function(results){
        this.uploadTickets(results[2]["tickets"], "tickets");
    },
    uploadTickets: function(results, type){
        var n = 100;
        var lists = _.groupBy(results, function(element, index){
            return Math.floor(index/n);
        });
        lists = _.toArray(lists); //Added this to convert the returned object to an array.
        for (var i = 0; i < lists.length; i++){
            var o = {};
            o[ type ] = lists[i];
            /*jshint -W083 */
            this.promise(function(done, fail) {
                this.ajax('sendData', o).then(
                    function(results) {
                        // do something with the data
                        done();     // ok to save the ticket
                    },
                    function(results) {
                        console.log(results.responseText);
                        done();     // failed, but save the ticket anyway
                    }
                );
            });
        }
    },
    guessDelimiter: function(text){
        var delimiters = [";",",","\t"];
        var count = [];
        _.each(delimiters, function(n, i){
            count[i] = text.split("\n")[0].split(n).length;
        });
        var max = count[0];
        var maxIndex = 0;
        for (var i = 1; i < count.length; i++){
            if (count[i] > max) {
                maxIndex = i;
                max = count[i];
            }
        }
        return delimiters[maxIndex];
    },
	CSVtoJSON: function(strData, strDelimiter){
        if( strData.substr(-1) !== "\n" ) strData += "\n";
        // Create a regular expression to parse the CSV values.
        var objPattern = new RegExp(
            (
                // Delimiters.
                "(\\" + strDelimiter + "|\\r?\\n|\\r|^)" +

                // Quoted fields.
                "(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|" +

                // Standard fields.
                "([^\"\\" + strDelimiter + "\\r\\n]*))"
            ),
            "gi"
            );
        
        // Create an array to hold our data.
        var jsonData = [];
        //if importing tickets
        var jsonData2 = {};
        ///////////////// create the name of the object based on what is selected in the interface
        var sel = 'tickets';
        jsonData2[ sel ] = [];
        ////////////
        // Create an array to hold our individual pattern
        // matching groups.
        var arrMatches = null;
        var keys = [];
        var row = [];
        var results = [];
        // Keep looping over the regular expression matches
        // until we can no longer find a match.
        while ((arrMatches = objPattern.exec( strData )) !== null){
            // Get the delimiter that was found.
            var strMatchedDelimiter = arrMatches[ 1 ];

            // Check to see if the given delimiter has a length
            // (is not the start of string) and if it matches
            // field delimiter. If id does not, then we know
            // that this delimiter is a row delimiter.
            var newRow = strMatchedDelimiter.length && (strMatchedDelimiter != strDelimiter);
            var strMatchedValue;
            if ( newRow ){
                // first row is the keys
                if(!keys.length){
                    keys = row;
                } else {
                    // Since we have reached a new row of data,
                    // add an empty row to our data array.
                    // combine row with keys
                    var data = {};
                    var data2 = {};
                    for (var i in row){
                        //store in array if preview is possible
                        if(!this.isFunction(row[i]) && typeof row[i] !== 'undefined'){
                            var contentB = row[i].toLowerCase();
                            if (contentB == "false"){
                                row[i] = false;
                            } else if (contentB == "true"){
                                row[i] = true;
                            }
                            data[ keys[i] ] = row[i];
                            if (keys[i].split("/").length > 1){
                                var d3 = keys[i].split("/");
                                var d3string = "data2";
                                //
                                for (var d = 0; d < d3.length; d++){
                                    var variable = d3string;
                                    var exec, condition;
                                    if (isNaN(d3[d])){
                                        if(!isNaN(d3[d - 1]) && d > 0){
                                            exec = d3string + " = {}";
                                            condition = "if (typeof " + variable + " == 'undefined'){" + exec + "}";
                                            /*jshint -W061 */
                                            eval(condition);
                                        }
                                        d3string += "['" + d3[d] +  "']";
                                    } else {
                                        //initialize object for previous d3 if it exists
                                        exec = d3string + " = [];";
                                        condition = "if (typeof " + variable + " == 'undefined'){" + exec + "}";
                                        /*jshint -W061 */
                                        eval(condition);
                                        d3string += "[" + d3[d] + "]";
                                    }
                                }
                                d3string += isNaN(row[i]) ? " = '" + row[i] + "'" : " = " + row[i];
                                /*jshint -W061 */
                                eval(d3string);
                            } else {
                                data2[ keys[i] ] = row[i];
                            }
                        }
                    }
                    jsonData.push( data );
                    //if importing tickets
                    jsonData2[ "tickets" ].push( data2 );
                }
                // eighter way reset the row
                row = [];
            }


            // Now that we have our delimiter out of the way,
            // let's check to see which kind of value we
            // captured (quoted or unquoted).
            if (arrMatches[ 2 ]){

                // We found a quoted value. When we capture
                // this value, unescape any double quotes.
                strMatchedValue = arrMatches[ 2 ].replace(
                    new RegExp( "\"\"", "g" ),
                    "\""
                    );
            } else {
                // We found a non-quoted value.
                strMatchedValue = arrMatches[ 3 ];
            }
            // Now that we have our value string, let's add
            // it to the data array.
            row.push( strMatchedValue );
        }
        results.push(jsonData); //results[0]
        results.push(keys); //results[1]
        results.push(jsonData2); //results[2]
        // Return the parsed data.
        return( results );
    },
    isFunction: function(functionToCheck){
        var getType = {};
        return functionToCheck && getType.toString.call(functionToCheck) === '[object Function]';
    },
  };
}());
